const express = require('express');
const router = express.Router();
const { ObjectId } = require('mongodb');
const { sendBookingConfirmation } = require('../utils/emailService');
const Booking = require('../models/booking');

// Create a new booking
router.post('/', async (req, res) => {
    try {
        const { name, email, phone, date, time, readingType } = req.body;
        
        // Validate required fields
        if (!name || !email || !phone || !date || !time || !readingType) {
            return res.status(400).json({ message: 'All fields are required' });
        }
        
        // Validate email format
        if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
            return res.status(400).json({ message: 'Invalid email format' });
        }

        // Validate phone format (10 digits)
        if (!phone.match(/^\d{10}$/)) {
            return res.status(400).json({ message: 'Phone number must be 10 digits' });
        }

        // Validate date format and ensure it's not in the past
        const bookingDate = new Date(`${date}T${time}`);
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        if (isNaN(bookingDate.getTime())) {
            return res.status(400).json({ message: 'Invalid date format' });
        }

        if (bookingDate < today) {
            return res.status(400).json({ message: 'Cannot book appointments in the past' });
        }

        // Validate time format and range (3 PM to 11 PM)
        const timeHour = parseInt(time.split(':')[0]);
        if (timeHour < 15 || timeHour > 23) {
            return res.status(400).json({ message: 'Time must be between 3 PM and 11 PM' });
        }

        // Validate reading type and set duration
        const readingDetails = {
            quick: {
                duration: 15,
                price: 300,
                name: 'Quick Insight'
            },
            spiritual: {
                duration: 30,
                price: 500,
                name: 'Spiritual Path'
            },
            celestial: {
                duration: 60,
                price: 700,
                name: 'Celestial Journey'
            }
        };

        if (!readingDetails[readingType]) {
            return res.status(400).json({ message: 'Invalid reading type' });
        }

        // Calculate end time based on duration
        const startTime = new Date(`${date}T${time}`);
        const endTime = new Date(startTime.getTime() + readingDetails[readingType].duration * 60000);

        // Check for overlapping bookings
        const existingBooking = await Booking.findOne({
            date,
            $or: [
                {
                    time: {
                        $gte: time,
                        $lt: endTime.toTimeString().slice(0, 5)
                    }
                },
                {
                    endTime: {
                        $gt: time,
                        $lte: endTime.toTimeString().slice(0, 5)
                    }
                }
            ]
        });

        if (existingBooking) {
            return res.status(409).json({ message: 'This time slot is already booked' });
        }

        // Create new booking
        const booking = new Booking({
            name,
            email,
            phone,
            date,
            time,
            endTime: endTime.toTimeString().slice(0, 5),
            readingType,
            duration: readingDetails[readingType].duration,
            price: readingDetails[readingType].price,
            readingName: readingDetails[readingType].name
        });

        await booking.save();

        // Send confirmation email
        try {
            const emailContent = `
                Dear ${name},

                Your ${readingDetails[readingType].name} session has been confirmed!

                Details:
                - Date: ${new Date(date).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                - Time: ${time}
                - Duration: ${readingDetails[readingType].duration} minutes
                - Price: ₹${readingDetails[readingType].price}

                Please be ready 5 minutes before your scheduled time. The session link will be sent 30 minutes before the appointment.

                Looking forward to guiding you on your spiritual journey.

                Mystical blessings,
                Your Tarot Guide
            `;

            await sendBookingConfirmation({
                to: email,
                subject: 'Your Tarot Reading Confirmation',
                text: emailContent
            });
        } catch (emailError) {
            console.error('Error sending confirmation email:', emailError);
            // Don't fail the booking if email fails
        }

        res.status(201).json({
            message: 'Booking confirmed',
            booking: {
                name,
                email,
                phone,
                date,
                time,
                readingType: readingDetails[readingType].name,
                duration: readingDetails[readingType].duration,
                price: readingDetails[readingType].price
            }
        });
    } catch (error) {
        console.error('Error creating booking:', error);
        res.status(500).json({ message: 'Error creating booking', error: error.message });
    }
});

// Get all bookings
router.get('/', async (req, res) => {
    try {
        const db = req.app.locals.mongoClient.db('tarot-readings');
        const bookings = await db.collection('bookings').find().toArray();
        res.json(bookings);
    } catch (error) {
        console.error('Error fetching bookings:', error);
        res.status(500).json({ message: 'Error fetching bookings', error: error.message });
    }
});

// Get available time slots for a date
router.get('/available-slots/:date', async (req, res) => {
    try {
        const date = req.params.date;
        
        // Validate date format
        if (!date.match(/^\d{4}-\d{2}-\d{2}$/)) {
            return res.status(400).json({ message: 'Invalid date format. Please use YYYY-MM-DD' });
        }

        // Get all bookings for the date
        const db = req.app.locals.mongoClient.db('tarot-readings');
        const bookings = await db.collection('bookings')
            .find({
                appointmentDate: {
                    $gte: new Date(`${date}T00:00:00`),
                    $lte: new Date(`${date}T23:59:59`)
                },
                status: 'confirmed'
            })
            .project({ appointmentDate: 1 })
            .toArray();
        
        // Define available time slots (3 PM to 11 PM)
        const allTimeSlots = [
            '15:00', '16:00', '17:00', '18:00', '19:00',
            '20:00', '21:00', '22:00', '23:00'
        ];
        
        // Filter out booked slots
        const bookedSlots = bookings.map(booking => 
            new Date(booking.appointmentDate).toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' })
        );
        const availableSlots = allTimeSlots.filter(slot => !bookedSlots.includes(slot));
        
        res.json({ availableSlots });
    } catch (error) {
        console.error('Error getting available slots:', error);
        res.status(500).json({ message: 'Failed to get available time slots' });
    }
});

// Get a specific booking
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const db = req.app.locals.mongoClient.db('tarot-readings');
        const booking = await db.collection('bookings').findOne({ _id: new ObjectId(id) });
        if (!booking) {
            return res.status(404).json({ message: 'Booking not found' });
        }
        res.json(booking);
    } catch (error) {
        console.error('Error fetching booking:', error);
        res.status(500).json({ message: 'Error fetching booking', error: error.message });
    }
});

// Update a booking
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const update = req.body;
        
        const db = req.app.locals.mongoClient.db('tarot-readings');
        const result = await db.collection('bookings').findOneAndUpdate(
            { _id: new ObjectId(id) },
            { $set: update },
            { returnDocument: 'after' }
        );
        
        if (!result.value) {
            return res.status(404).json({ message: 'Booking not found' });
        }
        
        res.json(result.value);
    } catch (error) {
        console.error('Error updating booking:', error);
        res.status(500).json({ message: 'Error updating booking', error: error.message });
    }
});

// Delete/Cancel a booking
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        
        const db = req.app.locals.mongoClient.db('tarot-readings');
        const result = await db.collection('bookings').findOneAndUpdate(
            { _id: new ObjectId(id) },
            { $set: { status: 'cancelled' } },
            { returnDocument: 'after' }
        );
        
        if (!result.value) {
            return res.status(404).json({ message: 'Booking not found' });
        }
        
        res.json({ message: 'Booking cancelled successfully', booking: result.value });
    } catch (error) {
        console.error('Error cancelling booking:', error);
        res.status(500).json({ message: 'Error cancelling booking', error: error.message });
    }
});

module.exports = router;

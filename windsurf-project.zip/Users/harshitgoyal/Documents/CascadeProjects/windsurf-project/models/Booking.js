const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        lowercase: true,
        trim: true
    },
    phone: {
        type: String,
        required: true
    },
    readingType: {
        type: String,
        required: true,
        enum: ['celestial', 'spiritual', 'quick']
    },
    status: {
        type: String,
        default: 'pending',
        enum: ['pending', 'confirmed', 'completed', 'cancelled']
    },
    zoomLink: {
        type: String
    },
    scheduledTime: {
        type: Date
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('Booking', bookingSchema);
